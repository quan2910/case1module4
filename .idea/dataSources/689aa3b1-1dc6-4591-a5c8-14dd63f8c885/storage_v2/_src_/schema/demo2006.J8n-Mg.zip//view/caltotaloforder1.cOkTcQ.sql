create definer = root@localhost view caltotaloforder1 as
select `c`.`name` AS `name`, `demo2006`.`order`.`id` AS `id`, sum((`p`.`price` * `o`.`quantity`)) AS `total`
from (((`demo2006`.`order` join `demo2006`.`orderdetail` `o`
        on ((`demo2006`.`order`.`id` = `o`.`orderId`))) join `demo2006`.`product` `p`
       on ((`p`.`id` = `o`.`productId`))) join `demo2006`.`customer` `c`
      on ((`demo2006`.`order`.`customerId` = `c`.`id`)))
group by `demo2006`.`order`.`id`;

