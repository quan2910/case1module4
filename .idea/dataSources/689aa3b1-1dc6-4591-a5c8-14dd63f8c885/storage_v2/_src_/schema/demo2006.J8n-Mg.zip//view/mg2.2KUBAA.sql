create definer = root@localhost view mg2 as
select `o`.`id` AS `id`, `o`.`time` AS `time`
from ((`demo2006`.`orderdetail` `od` join `demo2006`.`product` `p`) join `demo2006`.`order` `o`)
where ((`od`.`productId` = `p`.`id`) and (`o`.`id` = `od`.`orderId`) and (`p`.`name` like 'Máy Giặt') and
       (`od`.`quantity` > 10) and (`od`.`quantity` < 20));

